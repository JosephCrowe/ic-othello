(*******************************************************************************
 *  Colour module: contains the colour type.
 *)

(*******************************************************************************
 *  The colour that an Othello piece may possess.
 *)
type colour = BLACK | WHITE
